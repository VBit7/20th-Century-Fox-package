from classMainApp import MainApplication


def main():
    app = MainApplication()
    app.mainloop()


if __name__ == "__main__":
    main()